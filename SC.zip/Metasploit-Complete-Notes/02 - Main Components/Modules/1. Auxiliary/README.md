# Auxiliary Module

- Any supporting module, such as **scanners, crawlers and fuzzers**, can be found here. 

  ![Screenshot (832)](https://user-images.githubusercontent.com/63872951/184815074-2ab4f6a8-8c18-48cc-885a-7e2d2675dd1d.png)
