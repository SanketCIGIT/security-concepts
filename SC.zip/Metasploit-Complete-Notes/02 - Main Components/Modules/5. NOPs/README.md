# No OPeration  Module

- NOPs (No OPeration) do nothing, literally.

- They are represented in the **Intel x86** CPU family they are represented with **0x90**, following which the CPU will do nothing for one cycle. 
- They are often used as a buffer to achieve consistent payload sizes.

  ![Screenshot (837)](https://user-images.githubusercontent.com/63872951/184819485-f0728ebc-a403-440b-8bcf-ad0294b17d7a.png)
