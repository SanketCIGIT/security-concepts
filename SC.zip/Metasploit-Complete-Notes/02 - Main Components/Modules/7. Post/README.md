# Post Module

- Post modules will be useful on the **<ins>final</ins>** stage of the penetration testing process, ***post-exploitation***.

  ![Screenshot (839)](https://user-images.githubusercontent.com/63872951/184822394-2913d5a6-7f8a-45c1-8d0a-5e1188a25e35.png)
