# Evasion Module

- While encoders will encode the payload, they should not be considered a direct attempt to evade antivirus software.

- On the other hand, “evasion” modules will try that, with more or less success.

  ![Screenshot (834)](https://user-images.githubusercontent.com/63872951/184818458-fbfcec4f-6c22-42a1-b631-c9edb8e75cb6.png)
