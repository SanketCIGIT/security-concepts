# More Resources and Further Studies

### [1. List of Metasploit Learning Resouces](https://www.rapid7.com/resources/?p=Metasploit)
### [2. Rapid7](https://docs.rapid7.com/metasploit/)
### [3. Varonis Blogs](https://www.varonis.com/blog/what-is-metasploit)
### [4. SecurityTube Metasploit Framework Expert](http://www.securitytube.net/groups?operation=view&groupId=10)
### [5. ClassCentral - Metasploit Courses List](https://www.classcentral.com/subject/metasploit)
