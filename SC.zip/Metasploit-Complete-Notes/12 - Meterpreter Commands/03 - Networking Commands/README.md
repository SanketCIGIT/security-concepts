# Networking commands

  -  **`arp`**: Displays the host ARP (Address Resolution Protocol) cache
  -  **`ifconfig`**: Displays network interfaces available on the target system
  -  **`netstat`**: Displays the network connections
  -  **`portfwd`**: Forwards a local port to a remote service
  -  **`route`**: Allows you to view and modify the routing table

