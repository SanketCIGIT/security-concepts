# File System Commands


  -  **`cd`**: Will change directory
  -  **`ls`**: Will list files in the current directory (dir will also work)
  -  **`pwd`**: Prints the current working directory
  -  **`edit`**: will allow you to edit a file
  -  **`cat`**: Will show the contents of a file to the screen
  -  **`rm`**: Will delete the specified file
  -  **`search`**: Will search for files
  -  **`upload`**: Will upload a file or directory
  -  **`download`**: Will download a file or directory

