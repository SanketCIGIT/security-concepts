# Other Commands

   - **`idletime`**: Returns the number of seconds the remote user has been idle
   - **`keyscan_dump`**: Dumps the keystroke buffer
   - **`keyscan_start`**: Starts capturing keystrokes
   - **`keyscan_stop`**: Stops capturing keystrokes
   - **`screenshare`**: Allows you to watch the remote user's desktop in real time
   - **`screenshot`**: Grabs a screenshot of the interactive desktop
   - **`record_mic`**: Records audio from the default microphone for X seconds
   - **`webcam_chat`**: Starts a video chat
   - **`webcam_list`**: Lists webcams
   - **`webcam_snap`**: Takes a snapshot from the specified webcam
   - **`webcam_stream`**: Plays a video stream from the specified webcam
   - **`getsystem`**: Attempts to elevate your privilege to that of local system
   - **`hashdump`**: Dumps the contents of the SAM database

