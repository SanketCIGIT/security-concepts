# System commands

   - **`clearev`**: Clears the event logs
   - **`execute`**: Executes a command
   - **`getpid`**: Shows the current process identifier
   - **`getuid`**: Shows the user that Meterpreter is running as
   - **`kill`**: Terminates a process
   - **`pkill`**: Terminates processes by name
   - **`ps`**: Lists running processes
   - **`reboot`**: Reboots the remote computer
   - **`shell`**: Drops into a system command shell
   - **`shutdown`**: Shuts down the remote computer
   - **`sysinfo`**: Gets information about the remote system, such as OS

