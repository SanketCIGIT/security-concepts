# Intro to Msfvenom

- ***Msfvenom***, which replaced ***Msfpayload*** and ***Msfencode***, allows you to **generate payloads**.

- Msfvenom will allow you to access all payloads available in the Metasploit framework. 

- Msfvenom allows you to create payloads in many different formats (PHP, exe, dll, elf, etc.) and for many different target systems (Apple, Windows, Android, Linux, etc.).

    ![image](https://user-images.githubusercontent.com/63872951/187033734-24949fff-be43-4bbb-9689-244ee0849096.png)

# Output Formats

- You can either generate ***stand-alone*** payloads (e.g. a Windows executable for Meterpreter) or get a usable raw format (e.g. python). 

- The `msfvenom --list` formats command can be used to list supported output formats.

- **[Continue](https://github.com/ShubhamJagtap2000/Metasploit/tree/main/09%20-%20msfvenom/02%20-%20Encoders)**
