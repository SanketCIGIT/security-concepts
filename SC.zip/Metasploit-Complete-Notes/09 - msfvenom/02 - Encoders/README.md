# Encoders

- Contrary to some beliefs, encoders ***do not*** aim to ***bypass*** antivirus installed on the target system. As the name suggests, they ***<ins>encode</ins> the payload***. 

- While it can be effective against some antivirus software, using modern obfuscation techniques or learning methods to inject shellcode is a better solution to the problem. 

- The example below shows the usage of encoding (with the `-e` parameter. The PHP version of Meterpreter was encoded in `Base64`, and the output format was `raw`.)

  ![image](https://user-images.githubusercontent.com/63872951/187033852-6304c80f-ddd6-4f33-a740-f61d0dccb34b.png)

- **[Continue](https://github.com/ShubhamJagtap2000/Metasploit/tree/main/09%20-%20msfvenom/03%20-%20Handlers)**
